function gsted()

master = imread('input.png');

objs = detect(master);
props = prop(objs);
output = overlay(master, props);
imshow(output);
imwrite(output, 'output.png');

end