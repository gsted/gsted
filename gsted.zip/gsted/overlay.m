function [output] = overlay(master, props)





output = master;

%%loop through each rectangle in image.
[numberObjects, ~] = size(props);
for i = 1:numberObjects
    %%find the x,y of the hat object.
    MyImages = dir(fullfile(pwd, 'Hats','*.png'));
    RandomNumber = randi([1 size(MyImages,1)]);
    MyRandomImage = MyImages(RandomNumber).name;

    f = fullfile('Hats', MyRandomImage);
    
    hat = imread(f);%%change this to myrandomimage

    hat2 = imrotate(hat, props(i).Orientation);
    
    hat2 = imresize(hat2,props(i).MajorAxisLength/100);
    
    
    objs = detect(hat2);
    theHatsProps = prop(objs);
    centHat = theHatsProps(1).Centroid;
    y = centHat(2);
    x = centHat(1);
    
    
    %%find x, y of rectangle in picture;
    sentO = props(i).Centroid;
    y2 = sentO(2);
    x2 = sentO(1);
    
    
    startx = x2 - x;
    starty = y2 - y;
    
    %%setup the for loop for copy
    [hY, hX, ~] = size(hat2);
    
    [oY, oX, ~] = size(master);
    
    
    getredchannel = hat2(:,:,1);
    getgreenchannel = hat2(:,:,2);
    getbluechannel = hat2(:,:,3);
    
    for i = 1:hY
        for j = 1:hX
            
            if((getredchannel(i, j) == 0) && (getgreenchannel(i, j) == 0) && (getbluechannel(i, j) == 0))
                continue;
            end
            putx = floor(startx + j);
            puty = floor(starty + i);
            if((putx > oX) || (puty > oY) || (putx < 1) || (puty < 1))
                continue;
            end
            output(puty, putx, 1) = getredchannel(i, j);
            output(puty, putx, 2) = getgreenchannel(i, j);
            output(puty, putx, 3) = getbluechannel(i, j);
        end
    end
    
    
    
end










end
