function [props] = prop(objs)

props = regionprops(objs,'MajorAxisLength', 'Centroid', 'Orientation');

end

