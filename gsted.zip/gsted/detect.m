function [objs] = detect(master)

imshow(master);
getredchannel = master(:,:,1);
getgreenchannel = master(:,:,2);
getbluechannel = master(:,:,3);
[y,x,z] = size(master);
toReturn = zeros(y, x);

for thex = 1:x
    for they = 1:y
        if((getredchannel(they, thex) == 255) & (getgreenchannel(they, thex) == 0) & (getbluechannel(they, thex) == 0))
               toReturn(they, thex) = 1;
        end
    end
end

objs = bwlabel(toReturn);
end
